# minishell
minishell

To install readline library: 
```bash
    sudo apt-get update
    sudo apt-get install libreadline-dev
```

```c
# include <stdio.h>

int main()
{
    int i = 0;

    printf("%d\n", i);
    return (0);
}
```
